package opentaps.lead;

import org.testng.annotations.Test;

public class CreateContact extends OpentapsWrappers{
  @Test
  public void f() throws InterruptedException {
	  System.out.println("create lead is executed");
	  Thread.sleep(5000);
  }
}
